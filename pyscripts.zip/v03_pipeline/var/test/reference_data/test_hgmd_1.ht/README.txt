This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.114-cc8d36408b36
  Created at 2023/07/13 19:24:41