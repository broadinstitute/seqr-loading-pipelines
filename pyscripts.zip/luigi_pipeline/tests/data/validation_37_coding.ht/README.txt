This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.11-cf54f08305d1
  Created at 2019/03/25 14:45:56