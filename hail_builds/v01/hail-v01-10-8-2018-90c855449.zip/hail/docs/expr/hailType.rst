This is a Hail type. Values of this type have two representations: the
expression language representation and the Python representation.
