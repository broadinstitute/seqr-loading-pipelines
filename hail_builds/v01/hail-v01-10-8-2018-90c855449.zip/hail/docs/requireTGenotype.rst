.. important::

    The :py:meth:`~hail.VariantDataset.genotype_schema` must be of type :py:class:`~hail.expr.TGenotype` in order to use this method.

