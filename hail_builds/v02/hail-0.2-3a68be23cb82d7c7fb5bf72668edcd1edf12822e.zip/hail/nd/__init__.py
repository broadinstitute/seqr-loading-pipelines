from .nd import array, full, zeros, ones

__all__ = ["array", "full", "zeros", "ones"]