from .misc import array_windows, locus_windows, _check_dims

__all__ = ['array_windows',
           'locus_windows',
           '_check_dims']