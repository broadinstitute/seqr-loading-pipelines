String functions
----------------
.. currentmodule:: hail.expr.functions

.. autosummary::

    format
    json
    hamming
    delimit
    entropy

.. autofunction:: format
.. autofunction:: json
.. autofunction:: hamming
.. autofunction:: delimit
.. autofunction:: entropy
