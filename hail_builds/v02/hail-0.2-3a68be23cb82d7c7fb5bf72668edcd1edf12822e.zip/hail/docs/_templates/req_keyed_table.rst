.. note::

    Requires a keyed table.
