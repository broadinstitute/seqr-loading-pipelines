.. note::

    Requires the dataset to contain only diploid genotype calls.
