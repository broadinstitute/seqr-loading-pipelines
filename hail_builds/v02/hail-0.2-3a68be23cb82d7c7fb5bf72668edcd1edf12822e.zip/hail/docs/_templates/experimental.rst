.. DANGER::

    This functionality is *experimental*.  It may not be tested as
    well as other parts of Hail and the interface is subject to
    change.
