.. note::

    Requires the column key to be one field of type :py:data:`.tstr`