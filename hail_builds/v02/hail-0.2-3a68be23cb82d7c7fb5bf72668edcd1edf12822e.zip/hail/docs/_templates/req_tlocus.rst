.. note::

    Requires that the row key starts with:

     - `locus` (type :class:`.tlocus`)