stats
=====


.. toctree::
    :maxdepth: 2

.. currentmodule:: hail.stats

.. rubric:: Classes

.. autosummary::
    :nosignatures:
    :toctree: ./
    :template: class.rst

    LinearMixedModel
