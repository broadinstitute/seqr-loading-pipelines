
complete_states = ('Cancelled', 'Error', 'Failed', 'Success')
